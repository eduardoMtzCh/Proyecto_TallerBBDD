
package pruebasql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;


public class Conexion {

    public static Connection getConexion(){
        
        String conexionURL = "jdbc:sqlserver://localhost:1433;" 
                +"database=PANADERIA;"
                +"user=EDDY;"
                +"password=123;"
                +"loginTimeout=30;";
        
        try {
            Connection con = DriverManager.getConnection(conexionURL);
            System.out.println("Estoy dentro");
            return con;
        } catch (Exception e) {
            System.out.println(e.toString());
            return null;
        }
        
    }
    
    public static void main(String[] args) {
        
        /*
        String bases = "";
        String consulta = "";
        Scanner sc=new Scanner(System.in);
        
        
        try{
            Statement sql = getConexion().createStatement();
            
            System.out.println("Ingrese su consulta: ");
            consulta = sc.nextLine();
            ResultSet resultado = sql.executeQuery(consulta);
            
            while(resultado.next()){
                bases+=resultado.getString(1) + "\n";
            }
            System.out.println(bases);
        }
        
        catch (SQLException e) {
            System.out.println(e.toString());
        }*/
    }
    
}

//https://www.youtube.com/watch?v=_xG1vjSZrjI