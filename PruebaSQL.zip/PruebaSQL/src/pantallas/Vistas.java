
package pantallas;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import static pruebasql.Conexion.getConexion;


public class Vistas extends javax.swing.JFrame {

    public Vistas() {
        try {
            initComponents();
            cargarTabla();
        } catch (SQLException ex) {
            Logger.getLogger(Vistas.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        tblPrincipal = new javax.swing.JTable();
        jMenuBar1 = new javax.swing.JMenuBar();
        BusquedaVistaMenu = new javax.swing.JMenu();
        panSucursalMenu = new javax.swing.JMenuItem();
        panaderoClietneManu = new javax.swing.JMenuItem();
        sucursalClienteMenu = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        tblPrincipal.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane1.setViewportView(tblPrincipal);

        BusquedaVistaMenu.setText("Busqueda Avanzada");

        panSucursalMenu.setText("Pan-Sucursal");
        BusquedaVistaMenu.add(panSucursalMenu);

        panaderoClietneManu.setText("Panadero-Cliente");
        BusquedaVistaMenu.add(panaderoClietneManu);

        sucursalClienteMenu.setText("Sucursal-Cliente");
        BusquedaVistaMenu.add(sucursalClienteMenu);

        jMenuBar1.add(BusquedaVistaMenu);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(70, 70, 70)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 595, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(72, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(39, 39, 39)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(77, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    
      public void cargarTabla() throws SQLException {
        String[] registros = new String[200];
        String consulta = "SELECT * FROM PAN_SUCURSAL";
        DefaultTableModel model = new DefaultTableModel();

        try {
            Statement st = getConexion().createStatement();
            ResultSet resultado = st.executeQuery(consulta);
            ResultSetMetaData resultadoMD = resultado.getMetaData();
            int cantidadColumnas = resultadoMD.getColumnCount();

            model.addColumn("Sucursal");
            model.addColumn("Pan");
            model.addColumn("Disponible");
      
            while (resultado.next()) {
                Object[] filas = new Object[cantidadColumnas];

                for (int i = 0; i < cantidadColumnas; i++) {
                    filas[i] = resultado.getObject(i + 1);
                }
                model.addRow(filas);
            }
            tblPrincipal.setModel(model);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex);
        }
    }
   
    public static void main(String args[]) throws SQLException {
    
    


   
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Vistas().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenu BusquedaVistaMenu;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JMenuItem panSucursalMenu;
    private javax.swing.JMenuItem panaderoClietneManu;
    private javax.swing.JMenuItem sucursalClienteMenu;
    private javax.swing.JTable tblPrincipal;
    // End of variables declaration//GEN-END:variables
}
