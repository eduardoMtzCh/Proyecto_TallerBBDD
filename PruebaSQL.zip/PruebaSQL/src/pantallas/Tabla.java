package pantallas;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import static pruebasql.Conexion.getConexion;

public class Tabla extends javax.swing.JFrame {

    public Tabla() {
        initComponents();
        txtId.setVisible(false);
        txtNombre.setVisible(false);
        txt3.setVisible(false);
        txt4.setVisible(false);
        txt5.setVisible(false);
        txt6.setVisible(false);
    }

    public void cargarComponentes() {

        lblId.setText("Id");
        txtId.setVisible(true);
        txtNombre.setVisible(true);

        txtId.setText("");
        txtNombre.setText("");
        txt3.setText("");
        txt4.setText("");
        txt5.setText("");
        txt6.setText("");

        switch (cbxTablaSelecionada.getSelectedItem().toString()) {
            case "CLIENTE":
                lblNombre.setText("Nombre");
                lbl3.setText("Direccion");
                lbl4.setText("Telefono");
                lbl5.setText("");
                lbl6.setText("");

                txt3.setVisible(true);
                txt4.setVisible(true);

                txt5.setVisible(false);
                txt6.setVisible(false);

                break;

            case "PEDIDO":
                lblNombre.setText("Fecha");
                lbl3.setText("Monto");
                lbl4.setText("Id Cliente");
                lbl5.setText("Id Panadero");
                lbl6.setText("Id Pan");

                txt3.setVisible(true);
                txt4.setVisible(true);
                txt5.setVisible(true);
                txt6.setVisible(true);

                break;

            case "PANADERO":
                lblNombre.setText("Nombre");
                lbl3.setText("Sueldo");
                lbl4.setText("Horario");
                lbl5.setText("Id Sucursal");
                lbl6.setText("");

                txt3.setVisible(true);
                txt4.setVisible(true);
                txt5.setVisible(true);

                txt6.setVisible(false);
                break;

            case "SUCURSAL":
                lblNombre.setText("Nombre");
                lbl3.setText("Direccion");
                lbl4.setText("Telefono");
                lbl5.setText("");
                lbl6.setText("");

                txt3.setVisible(true);
                txt4.setVisible(true);

                txt5.setVisible(false);
                txt6.setVisible(false);
                break;

            case "PAN":
                lblNombre.setText("Nombre");
                lbl3.setText("Stock");
                lbl4.setText("");
                lbl5.setText("");
                lbl6.setText("");

                txt3.setVisible(true);

                txt4.setVisible(false);
                txt5.setVisible(false);
                txt6.setVisible(false);
                break;

        }
    }

    public void cargarTabla() throws SQLException {
        String[] registros = new String[200];
        String consulta = "SELECT * FROM " + cbxTablaSelecionada.getSelectedItem().toString();
        DefaultTableModel model = new DefaultTableModel();

        try {
            Statement st = getConexion().createStatement();
            ResultSet resultado = st.executeQuery(consulta);
            ResultSetMetaData resultadoMD = resultado.getMetaData();
            int cantidadColumnas = resultadoMD.getColumnCount();

            switch (cbxTablaSelecionada.getSelectedItem().toString()) {
                case "CLIENTE":
                    model.addColumn("Id");
                    model.addColumn("Nombre");
                    model.addColumn("Direccion");
                    model.addColumn("Telefono");

                    while (resultado.next()) {
                        Object[] filas = new Object[cantidadColumnas];

                        for (int i = 0; i < cantidadColumnas; i++) {
                            filas[i] = resultado.getObject(i + 1);
                        }
                        model.addRow(filas);
                    }
                    break;
                case "PEDIDO":
                    model.addColumn("Id");
                    model.addColumn("Fecha");
                    model.addColumn("Monto");
                    model.addColumn("Id Panadero");
                    model.addColumn("Id Pan");

                    while (resultado.next()) {
                        Object[] filas = new Object[cantidadColumnas];

                        for (int i = 0; i < cantidadColumnas; i++) {
                            filas[i] = resultado.getObject(i + 1);
                        }
                        model.addRow(filas);
                    }
                    break;
                case "PANADERO":
                    model.addColumn("Id");
                    model.addColumn("Nombre");
                    model.addColumn("Sueldo");
                    model.addColumn("Horario");
                    model.addColumn("Id Sucursal");

                    while (resultado.next()) {
                        Object[] filas = new Object[cantidadColumnas];

                        for (int i = 0; i < cantidadColumnas; i++) {
                            filas[i] = resultado.getObject(i + 1);
                        }
                        model.addRow(filas);
                    }

                    break;
                case "SUCURSAL":
                    model.addColumn("Id");
                    model.addColumn("Nombre");
                    model.addColumn("Direccion");
                    model.addColumn("Telefono");

                    while (resultado.next()) {
                        Object[] filas = new Object[cantidadColumnas];

                        for (int i = 0; i < cantidadColumnas; i++) {
                            filas[i] = resultado.getObject(i + 1);
                        }
                        model.addRow(filas);
                    }
                    break;
                case "PAN":
                    model.addColumn("Id");
                    model.addColumn("Nombre");
                    model.addColumn("Stock");

                    while (resultado.next()) {
                        Object[] filas = new Object[cantidadColumnas];

                        for (int i = 0; i < cantidadColumnas; i++) {
                            filas[i] = resultado.getObject(i + 1);
                        }
                        model.addRow(filas);
                    }
                    break;
            }

            tblPrincipal.setModel(model);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton2 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblPrincipal = new javax.swing.JTable();
        cbxTablaSelecionada = new javax.swing.JComboBox<>();
        lblId = new javax.swing.JLabel();
        txtId = new javax.swing.JTextField();
        lblNombre = new javax.swing.JLabel();
        txtNombre = new javax.swing.JTextField();
        lbl3 = new javax.swing.JLabel();
        lbl4 = new javax.swing.JLabel();
        lbl5 = new javax.swing.JLabel();
        lbl6 = new javax.swing.JLabel();
        txt3 = new javax.swing.JTextField();
        txt4 = new javax.swing.JTextField();
        txt5 = new javax.swing.JTextField();
        txt6 = new javax.swing.JTextField();
        btnAgregar = new javax.swing.JButton();
        btnConsulta = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();

        jButton2.setText("jButton1");

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        tblPrincipal.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane1.setViewportView(tblPrincipal);

        cbxTablaSelecionada.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        cbxTablaSelecionada.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "CLIENTE", "PANADERO", "SUCURSAL", "PAN" }));
        cbxTablaSelecionada.setToolTipText("");
        cbxTablaSelecionada.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbxTablaSelecionadaActionPerformed(evt);
            }
        });

        lblId.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        txtId.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtIdActionPerformed(evt);
            }
        });

        lblNombre.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        lbl3.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        lbl4.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        lbl5.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        lbl6.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        txt3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt3ActionPerformed(evt);
            }
        });

        txt6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt6ActionPerformed(evt);
            }
        });

        btnAgregar.setBackground(new java.awt.Color(0, 204, 102));
        btnAgregar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconos/icons8-check-24.png"))); // NOI18N
        btnAgregar.setPreferredSize(new java.awt.Dimension(46, 46));
        btnAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarActionPerformed(evt);
            }
        });

        btnConsulta.setBackground(new java.awt.Color(153, 204, 255));
        btnConsulta.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconos/icons8-magnifying-glass-24.png"))); // NOI18N
        btnConsulta.setPreferredSize(new java.awt.Dimension(46, 46));
        btnConsulta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConsultaActionPerformed(evt);
            }
        });

        btnEliminar.setBackground(new java.awt.Color(255, 102, 102));
        btnEliminar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconos/icons8-app-24.png"))); // NOI18N
        btnEliminar.setPreferredSize(new java.awt.Dimension(46, 46));
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(cbxTablaSelecionada, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(104, 104, 104)
                                .addComponent(btnAgregar, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnConsulta, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(lblId)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(txtId, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(lblNombre)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(lbl3)
                                    .addGap(18, 18, 18)
                                    .addComponent(txt3))
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(lbl4)
                                    .addGap(18, 18, 18)
                                    .addComponent(txt4))
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(lbl5)
                                    .addGap(18, 18, 18)
                                    .addComponent(txt5))
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(lbl6)
                                    .addGap(18, 18, 18)
                                    .addComponent(txt6))))
                        .addGap(0, 60, Short.MAX_VALUE))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 442, Short.MAX_VALUE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(11, 11, 11)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(50, 50, 50)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblId)
                            .addComponent(txtId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblNombre)
                            .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lbl3)
                            .addComponent(txt3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lbl4)
                            .addComponent(txt4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lbl5)
                            .addComponent(txt5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lbl6)
                            .addComponent(txt6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                        .addComponent(btnEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnAgregar, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnConsulta, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(cbxTablaSelecionada, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 43, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cbxTablaSelecionadaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbxTablaSelecionadaActionPerformed
        cargarComponentes();
        try {
            cargarTabla();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex);
        }
    }//GEN-LAST:event_cbxTablaSelecionadaActionPerformed

    private void txtIdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtIdActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtIdActionPerformed

    private void txt3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt3ActionPerformed

    private void txt6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt6ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt6ActionPerformed

    private void btnConsultaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConsultaActionPerformed

    }//GEN-LAST:event_btnConsultaActionPerformed

    private void btnAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarActionPerformed
        String consulta;
        switch (cbxTablaSelecionada.getSelectedItem().toString()) {
            case "CLIENTE":
                consulta = "INSERT INTO CLIENTE (no_cliente, nombre_cli, direccion, telefono)VALUES("
                        + txtId.getText() + ",'"
                        + txtNombre.getText() + "','"
                        + txt3.getText() + "','"
                        + txt4.getText() + "')";
                try {
                    Statement st = getConexion().createStatement();
                    st.executeQuery(consulta);
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(null, ex);
                }
                break;

            case "PEDIDO":
                consulta = "INSERT INTO PEDIDO (no_pedido, fecha, monto, no_panadero, no_pan)VALUES("
                        + txtId.getText() + ",'"
                        + txtNombre.getText() + "','"
                        + txt3.getText() + "','"
                        + txt5.getText() + "','"
                        + txt6.getText() + "')";
                try {
                    Statement st = getConexion().createStatement();
                    st.executeQuery(consulta);
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(null, ex);
                }
                break;

            case "PANADERO":
                consulta = "INSERT INTO PANADERO (no_panadero, nombre_pan, sueldo, horario, no_sucursal)VALUES("
                        + txtId.getText() + ",'"
                        + txtNombre.getText() + "','"
                        + txt3.getText() + "','"
                        + txt4.getText() + "','"
                        + txt5.getText() + "')";
                try {
                    Statement st = getConexion().createStatement();
                    st.executeQuery(consulta);
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(null, ex);
                }
                break;

            case "SUCURSAL":
                consulta = "INSERT INTO SUCURSAL (no_sucursal, nombre_sucu, direccion, telefono_suc)VALUES("
                        + txtId.getText() + ",'"
                        + txtNombre.getText() + "','"
                        + txt3.getText() + "','"
                        + txt4.getText() + "')";
                try {
                    Statement st = getConexion().createStatement();
                    st.executeQuery(consulta);
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(null, ex);
                }
                break;

            case "PAN":
                consulta = "INSERT INTO PAN (no_pan, nombre_pan, stock)VALUES("
                        + txtId.getText() + ",'"
                        + txtNombre.getText() + "','"
                        + txt3.getText() + "')";
                try {
                    Statement st = getConexion().createStatement();
                    st.executeQuery(consulta);
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(null, ex);
                }
                break;

        }
        try {
            cargarTabla();
        } catch (SQLException ex) {
            Logger.getLogger(Tabla.class.getName()).log(Level.SEVERE, null, ex);
        }

        cargarComponentes();
    }//GEN-LAST:event_btnAgregarActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        String consulta;
        switch (cbxTablaSelecionada.getSelectedItem().toString()) {
            case "CLIENTE":
                consulta = "DELETE FROM CLIENTE WHERE no_cliente = " + txtId.getText();
                try {
                    Statement st = getConexion().createStatement();
                    st.executeQuery(consulta);
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(null, ex);
                }
                break;

            case "PEDIDO":
                consulta = "DELETE FROM PEDIDO WHERE no_pedido = " + txtId.getText();
                try {
                    Statement st = getConexion().createStatement();
                    st.executeQuery(consulta);
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(null, ex);
                }
                break;

            case "PANADERO":
                consulta = "DELETE FROM PANADERO WHERE no_panadero = " + txtId.getText();
                try {
                    Statement st = getConexion().createStatement();
                    st.executeQuery(consulta);
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(null, ex);
                }
                break;

            case "SUCURSAL":
                consulta = "DELETE FROM SUCURSAL WHERE no_sucursal = " + txtId.getText();
                try {
                    Statement st = getConexion().createStatement();
                    st.executeQuery(consulta);
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(null, ex);
                }
                break;

            case "PAN":
                consulta = "DELETE FROM PAN WHERE no_pan = " + txtId.getText();
                try {
                    Statement st = getConexion().createStatement();
                    st.executeQuery(consulta);
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(null, ex);
                }
                break;

        }

        try {
            cargarTabla();
        } catch (SQLException ex) {
            Logger.getLogger(Tabla.class.getName()).log(Level.SEVERE, null, ex);
        }
        cargarComponentes();
    }//GEN-LAST:event_btnEliminarActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Tabla.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Tabla.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Tabla.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Tabla.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Tabla().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAgregar;
    private javax.swing.JButton btnConsulta;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JComboBox<String> cbxTablaSelecionada;
    private javax.swing.JButton jButton2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lbl3;
    private javax.swing.JLabel lbl4;
    private javax.swing.JLabel lbl5;
    private javax.swing.JLabel lbl6;
    private javax.swing.JLabel lblId;
    private javax.swing.JLabel lblNombre;
    private javax.swing.JTable tblPrincipal;
    private javax.swing.JTextField txt3;
    private javax.swing.JTextField txt4;
    private javax.swing.JTextField txt5;
    private javax.swing.JTextField txt6;
    private javax.swing.JTextField txtId;
    private javax.swing.JTextField txtNombre;
    // End of variables declaration//GEN-END:variables
}
